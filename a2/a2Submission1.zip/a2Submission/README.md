# Assignment 2 #
__By: John Ordoyo__

The assignment follows what is required, as specified in the pdf. Unfortunately upon shutting down, the user who receives the terminating signal "!" will need to hit enter again to properly shutdown.

The submission also includes a test for the implemented list monitor. To run, uncomment the lines that compile and create a "testMonitor" executable. It simply runs 4 concurrent threads with 2 consuming and 2 producing.
